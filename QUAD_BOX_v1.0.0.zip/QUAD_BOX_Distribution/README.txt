QUAD BOX - Multi-Screen Web Browser
===================================

⚠️  IMPORTANT SECURITY NOTICE ⚠️
If you see "QUAD BOX is damaged" or "unidentified developer" warnings:

SOLUTION 1 - Right-click method (RECOMMENDED):
1. Right-click on "QUAD BOX.app"
2. Select "Open" from the menu
3. Click "Open" in the security dialog
4. App will run normally from now on

SOLUTION 2 - System Preferences method:
1. Go to System Preferences > Security & Privacy > General
2. Look for blocked app message
3. Click "Open Anyway"

SOLUTION 3 - Terminal method (Advanced users):
1. Open Terminal
2. Type: sudo xattr -rd com.apple.quarantine "/path/to/QUAD BOX.app"
3. Replace /path/to/ with actual path to the app

INSTALLATION:
1. Download and extract this folder
2. Drag "QUAD BOX.app" to your Applications folder
3. Use one of the security solutions above on first run

FEATURES:
- One/Dual-Screen/Triangle/Quad Box layouts
- Active browser selection with audio control
- Built-in popup blocker
- Custom URL loading for any website
- Perfect for monitoring multiple streams

SYSTEM REQUIREMENTS:
- macOS 10.15 (Catalina) or later
- Intel or Apple Silicon Mac

USAGE:
- Use layout buttons to switch between 1, 2, 3, or 4 screens
- Click Active buttons (1-4) to control which browser has audio
- Enter URLs in the bottom field and click Load
- Active browser has blue border and plays audio

WHY THE SECURITY WARNING?
This app is not signed by a registered Apple developer ($99/year).
The app is completely safe - it only displays web content.
Apple requires this warning for unsigned apps.

© 2025 QUAD BOX. All rights reserved.
